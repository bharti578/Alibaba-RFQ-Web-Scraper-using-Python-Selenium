from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import csv
from datetime import datetime
import time

def scrape_alibaba_rfq():
    print("Starting Alibaba RFQ scraping...")
    
    # Setup Chrome driver
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    base_url = "https://sourcing.alibaba.com/rfq/rfq_search_list.htm"
    params = {
        "country": "AE",
        "recently": "Y",
        "tracelog": "newest"
    }
    
    # Output CSV file name
    csv_filename = "alibaba_rfq_data.csv"
    
    try:
        # Construct URL with parameters
        query_string = "&".join(f"{k}={v}" for k, v in params.items())
        url = f"{base_url}?{query_string}"
        print(f"Accessing URL: {url}")
        driver.get(url)
        time.sleep(5)  # Wait for page to load completely
        
        all_rfqs = []
        page = 1
        max_pages = 3  # Limit pages for demo (remove or increase for full scrape)
        
        while page <= max_pages:
            print(f"\nScraping page {page}...")
            
            # Find all RFQ items
            rfq_items = driver.find_elements(By.CSS_SELECTOR, '.rfq-item')
            if not rfq_items:
                print("No RFQs found on page. Exiting.")
                break
                
            print(f"Found {len(rfq_items)} RFQs on this page")
            
            for item in rfq_items:
                try:
                    rfq_data = {
                        "RFQ ID": item.get_attribute("data-rfq-id") or "NA",
                        "Title": item.find_element(By.CSS_SELECTOR, 'h4.rfq-title').text.strip(),
                        "Buyer Name": item.find_element(By.CSS_SELECTOR, 'span.buyer-name').text.strip(),
                        "Buyer Image": item.find_element(By.CSS_SELECTOR, 'img.buyer-img').get_attribute("src") or "NA",
                        "Inquiry Time": item.find_element(By.CSS_SELECTOR, 'span.inquiry-time').text.strip(),
                        "Quotes Left": item.find_element(By.CSS_SELECTOR, 'span.quotes-left').text.strip(),
                        "Country": item.find_element(By.CSS_SELECTOR, 'span.country').text.strip(),
                        "Quantity Required": item.find_element(By.CSS_SELECTOR, 'span.quantity').text.strip(),
                        "Email Confirmed": "Yes" if item.find_elements(By.CSS_SELECTOR, 'i.email-confirmed') else "No",
                        "Experienced Buyer": "Yes" if item.find_elements(By.CSS_SELECTOR, 'i.experienced-buyer') else "No",
                        "Complete Order via RFQ": "Yes" if item.find_elements(By.CSS_SELECTOR, 'i.complete-order') else "No",
                        "Typical Replies": "Yes" if item.find_elements(By.CSS_SELECTOR, 'i.typical-replies') else "No",
                        "Interactive User": "Yes" if item.find_elements(By.CSS_SELECTOR, 'i.interactive-user') else "No",
                        "Inquiry URL": "https://sourcing.alibaba.com" + item.find_element(By.CSS_SELECTOR, 'a.rfq-title-link').get_attribute("href"),
                        "Inquiry Date": datetime.now().strftime("%d-%m-%Y"),
                        "Scraping Date": datetime.now().strftime("%d-%m-%Y")
                    }
                    all_rfqs.append(rfq_data)
                except Exception as e:
                    print(f"Error scraping one RFQ: {str(e)[:100]}...")
                    continue
            
            # Pagination - Click next page if exists
            try:
                next_btn = driver.find_element(By.CSS_SELECTOR, 'a.next-page')
                next_btn.click()
                time.sleep(5)  # Wait for next page to load
                page += 1
            except:
                print("No more pages available.")
                break
                
    except Exception as e:
        print(f"Major error occurred: {e}")
    finally:
        driver.quit()
        print("Browser closed.")
        
        # Write to CSV
        print(f"\nWriting {len(all_rfqs)} RFQs to CSV...")
        with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                "RFQ ID", "Title", "Buyer Name", "Buyer Image", "Inquiry Time", 
                "Quotes Left", "Country", "Quantity Required", "Email Confirmed",
                "Experienced Buyer", "Complete Order via RFQ", "Typical Replies",
                "Interactive User", "Inquiry URL", "Inquiry Date", "Scraping Date"
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_rfqs)
        
        print(f"\n✅ Scraping completed successfully!")
        print(f"📄 CSV file created: {csv_filename}")

if __name__ == "__main__":
    scrape_alibaba_rfq()

